#!/bin/sh
pandoc README.md -o sprawozdanie.pdf -f markdown-implicit_figures
